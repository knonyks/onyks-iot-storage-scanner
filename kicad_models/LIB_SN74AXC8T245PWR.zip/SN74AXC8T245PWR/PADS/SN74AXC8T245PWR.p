*PADS-LIBRARY-PART-TYPES-V9*

SN74AXC8T245PWR SOP65P640X120-24N I ANA 7 1 0 0 0
TIMESTAMP 2025.08.19.16.39.07
"Mouser Part Number" 595-SN74AXC8T245PWR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74AXC8T245PWR?qs=r5DSvlrkXmJAK4f7nnPNow%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74AXC8T245PWR
"Description" 8-Bit Dual-Supply Bus Transceiver
"Datasheet Link" http://www.ti.com/lit/gpn/sn74axc8t245
"Geometry.Height" 1.2mm
GATE 1 24 0
SN74AXC8T245PWR
1 0 P VCCA
2 0 L DIR1
3 0 B A1
4 0 B A2
5 0 B A3
6 0 B A4
7 0 B A5
8 0 B A6
9 0 B A7
10 0 B A8
11 0 L DIR2
12 0 G GND_1
24 0 P VCCB_2
23 0 P VCCB_1
22 0 L OE
21 0 B B1
20 0 B B2
19 0 B B3
18 0 B B4
17 0 B B5
16 0 B B6
15 0 B B7
14 0 B B8
13 0 G GND_2

*END*
*REMARK* SamacSys ECAD Model
1125142/1665652/2.50/24/3/Integrated Circuit
