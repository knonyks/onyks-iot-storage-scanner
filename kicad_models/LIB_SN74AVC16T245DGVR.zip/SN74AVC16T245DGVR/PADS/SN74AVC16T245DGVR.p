*PADS-LIBRARY-PART-TYPES-V9*

SN74AVC16T245DGVR SOP40P640X120-48N I ANA 7 1 0 0 0
TIMESTAMP 2025.08.19.17.10.50
"Mouser Part Number" 595-SN74AVC16T245DGV
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74AVC16T245DGVR?qs=PVVDbbWpW3LuulEdQVrkTg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74AVC16T245DGVR
"Description" 16-Bit Dual-Supply Bus Transceiver with Configurable Voltage-Level Shifting and 3-State Outputs
"Datasheet Link" http://www.ti.com/lit/gpn/sn74avc16t245
"Geometry.Height" 1.2mm
GATE 1 48 0
SN74AVC16T245DGVR
1 0 U 1DIR
2 0 U 1B1
3 0 U 1B2
4 0 U GND_1
5 0 U 1B3
6 0 U 1B4
7 0 U VCCB_1
8 0 U 1B5
9 0 U 1B6
10 0 U GND_2
11 0 U 1B7
12 0 U 1B8
13 0 U 2B1
14 0 U 2B2
15 0 U GND_3
16 0 U 2B3
17 0 U 2B4
18 0 U VCCB_2
19 0 U 2B5
20 0 U 2B6
21 0 U GND_4
22 0 U 2B7
23 0 U 2B8
24 0 U 2DIR
48 0 U 1\OE
47 0 U 1A1
46 0 U 1A2
45 0 U GND_8
44 0 U 1A3
43 0 U 1A4
42 0 U VCCA_2
41 0 U 1A5
40 0 U 1A6
39 0 U GND_7
38 0 U 1A7
37 0 U 1A8
36 0 U 2A1
35 0 U 2A2
34 0 U GND_6
33 0 U 2A3
32 0 U 2A4
31 0 U VCCA_1
30 0 U 2A5
29 0 U 2A6
28 0 U GND_5
27 0 U 2A7
26 0 U 2A8
25 0 U 2\OE

*END*
*REMARK* SamacSys ECAD Model
293589/1665652/2.50/48/3/Integrated Circuit
